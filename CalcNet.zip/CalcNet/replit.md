# Overview

This is a comprehensive calculator web application built with a modern full-stack architecture. The application provides multiple types of calculators including financial, health & fitness, math, and other utility calculators. It features a clean, responsive design with a scientific calculator as the main component, along with specialized calculators for mortgages, BMI, age calculations, and more.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client-side is built using React 18 with TypeScript, utilizing a component-based architecture. The application uses Wouter for lightweight client-side routing, providing navigation between different calculator categories (home, financial, health, math, other). The UI is built with shadcn/ui components and Radix UI primitives, styled with Tailwind CSS for a modern, consistent design system.

The calculator functionality is centralized through custom hooks (`useCalculator`) that manage calculator state, history, and mathematical operations. The scientific calculator uses the mathjs library for expression evaluation, supporting both degree and radian angle modes for trigonometric functions.

## Backend Architecture
The backend follows a minimal Express.js server architecture with TypeScript. The server is designed to be lightweight, primarily serving the React application and providing API endpoints for future calculator history and user preference features. The current implementation includes basic health check endpoints with room for expansion.

The server uses middleware for request logging and error handling, with development-specific Vite integration for hot reloading. Production builds are handled through esbuild for optimal performance.

## Data Storage Solutions
The application uses Drizzle ORM with PostgreSQL as the primary database solution. The database schema is defined for calculator history storage, tracking expressions, results, calculator types, and timestamps. Currently, the application includes a memory-based storage implementation for development, with the database integration prepared for production use.

The storage interface is abstracted to support multiple storage backends, allowing for easy switching between memory storage (development) and PostgreSQL (production).

## UI Component System
The application leverages a comprehensive design system built on shadcn/ui and Radix UI primitives. This provides accessible, customizable components including cards, buttons, inputs, dialogs, tooltips, and form elements. The design uses CSS custom properties for theming with support for light/dark modes.

The calculator interface features a clean grid layout for buttons, a dark display area for calculations, and organized sections for different calculator types and functions.

## State Management
Client-side state is managed through React hooks and context providers. The calculator state includes display values, memory, angle modes, pending operations, and calculation history. TanStack Query is integrated for server state management and caching, though currently minimal server interaction is implemented.

The application maintains calculation history locally and provides functionality to clear or reference previous calculations.

# External Dependencies

## Database & ORM
- **Drizzle ORM**: Type-safe database operations with PostgreSQL dialect
- **@neondatabase/serverless**: Serverless PostgreSQL connection for production deployment
- **connect-pg-simple**: PostgreSQL session store for future authentication features

## UI & Styling
- **Radix UI**: Comprehensive set of accessible React components for dialogs, dropdowns, navigation, and form controls
- **Tailwind CSS**: Utility-first CSS framework for responsive design
- **shadcn/ui**: Pre-built component library built on Radix UI and Tailwind
- **Lucide React**: Icon library for consistent iconography
- **class-variance-authority**: Utility for managing component variants

## Mathematical Operations
- **mathjs**: Comprehensive math library for expression evaluation, scientific functions, and unit conversions
- **date-fns**: Date manipulation library for age calculations and time-based utilities

## Development & Build Tools
- **Vite**: Fast build tool and development server with React plugin
- **TypeScript**: Type-safe development environment
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Tailwind integration

## Client-Side Libraries
- **Wouter**: Lightweight React router for navigation
- **TanStack Query**: Server state management and caching
- **React Hook Form**: Form handling with validation
- **Embla Carousel**: Touch-friendly carousel component for mobile interfaces

## Server Dependencies
- **Express.js**: Web server framework
- **tsx**: TypeScript execution for development server
- **nanoid**: Unique ID generation for sessions and records
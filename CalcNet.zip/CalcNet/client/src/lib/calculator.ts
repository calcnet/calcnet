import { evaluate } from 'mathjs';

export interface CalculatorState {
  display: string;
  previousCalculation: string;
  memory: number;
  angleMode: 'deg' | 'rad';
  isNewNumber: boolean;
  pendingOperation: string | null;
  operand: number | null;
}

export const initialState: CalculatorState = {
  display: '0',
  previousCalculation: '',
  memory: 0,
  angleMode: 'deg',
  isNewNumber: true,
  pendingOperation: null,
  operand: null,
};

export class Calculator {
  static evaluateExpression(expression: string, angleMode: 'deg' | 'rad' = 'deg'): string {
    try {
      // Convert trigonometric functions based on angle mode
      let processedExpression = expression;
      
      if (angleMode === 'deg') {
        // Convert degrees to radians for trig functions
        processedExpression = processedExpression
          .replace(/sin\(([^)]+)\)/g, 'sin(($1) * pi / 180)')
          .replace(/cos\(([^)]+)\)/g, 'cos(($1) * pi / 180)')
          .replace(/tan\(([^)]+)\)/g, 'tan(($1) * pi / 180)');
      }

      // Replace mathematical symbols with JavaScript equivalents
      processedExpression = processedExpression
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/−/g, '-')
        .replace(/π/g, 'pi')
        .replace(/e(?![x])/g, 'e')
        .replace(/\^/g, '^')
        .replace(/sqrt\(/g, 'sqrt(')
        .replace(/ln\(/g, 'log(')
        .replace(/log\(/g, 'log10(');

      const result = evaluate(processedExpression);
      
      // Format the result
      if (typeof result === 'number') {
        if (Math.abs(result) > 1e15 || (Math.abs(result) < 1e-10 && result !== 0)) {
          return result.toExponential(10);
        }
        // Round to 12 decimal places to avoid floating point errors
        return parseFloat(result.toPrecision(12)).toString();
      }
      
      return result.toString();
    } catch (error) {
      throw new Error('Error');
    }
  }

  static formatNumber(num: string): string {
    const number = parseFloat(num);
    if (isNaN(number)) return num;
    
    // Handle very large or very small numbers
    if (Math.abs(number) > 1e15 || (Math.abs(number) < 1e-10 && number !== 0)) {
      return number.toExponential(10);
    }
    
    // Format with appropriate decimal places
    return parseFloat(number.toPrecision(12)).toString();
  }

  static scientificFunction(func: string, value: number, angleMode: 'deg' | 'rad' = 'deg'): number {
    switch (func) {
      case 'sin':
        return Math.sin(angleMode === 'deg' ? (value * Math.PI) / 180 : value);
      case 'cos':
        return Math.cos(angleMode === 'deg' ? (value * Math.PI) / 180 : value);
      case 'tan':
        return Math.tan(angleMode === 'deg' ? (value * Math.PI) / 180 : value);
      case 'asin':
        const asinResult = Math.asin(value);
        return angleMode === 'deg' ? (asinResult * 180) / Math.PI : asinResult;
      case 'acos':
        const acosResult = Math.acos(value);
        return angleMode === 'deg' ? (acosResult * 180) / Math.PI : acosResult;
      case 'atan':
        const atanResult = Math.atan(value);
        return angleMode === 'deg' ? (atanResult * 180) / Math.PI : atanResult;
      case 'log':
        return Math.log10(value);
      case 'ln':
        return Math.log(value);
      case 'sqrt':
        return Math.sqrt(value);
      case 'cbrt':
        return Math.cbrt(value);
      case 'square':
        return value * value;
      case 'cube':
        return value * value * value;
      case 'reciprocal':
        return 1 / value;
      case 'factorial':
        if (value < 0 || !Number.isInteger(value) || value > 170) {
          throw new Error('Invalid input for factorial');
        }
        let result = 1;
        for (let i = 2; i <= value; i++) {
          result *= i;
        }
        return result;
      case 'exp':
        return Math.exp(value);
      default:
        throw new Error('Unknown function');
    }
  }

  static getConstants(): Record<string, number> {
    return {
      pi: Math.PI,
      e: Math.E,
    };
  }
}

import { Link } from 'wouter';

export function Footer() {
  const footerLinks = {
    'Calculator.net': [
      'Free online calculators for finance, math, health, and more. Professional tools for everyday calculations.',
    ],
    Financial: [
      { href: '/financial', label: 'Mortgage Calculator' },
      { href: '/financial', label: 'Loan Calculator' },
      { href: '/financial', label: 'Investment Calculator' },
    ],
    'Health & Fitness': [
      { href: '/health', label: 'BMI Calculator' },
      { href: '/health', label: 'Calorie Calculator' },
      { href: '/health', label: 'Body Fat Calculator' },
    ],
    Math: [
      { href: '/math', label: 'Scientific Calculator' },
      { href: '/math', label: 'Fraction Calculator' },
      { href: '/math', label: 'Percentage Calculator' },
    ],
  };

  return (
    <footer className="bg-slate-800 text-white py-12 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {Object.entries(footerLinks).map(([title, items]) => (
            <div key={title}>
              <h3 className="text-lg font-semibold mb-4">{title}</h3>
              {typeof items[0] === 'string' ? (
                <p className="text-slate-300 text-sm">{items[0]}</p>
              ) : (
                <ul className="space-y-2 text-sm text-slate-300">
                  {(items as { href: string; label: string }[]).map((item) => (
                    <li key={item.label}>
                      <Link href={item.href}>
                        <a className="hover:text-white transition-colors">
                          {item.label}
                        </a>
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>
        <div className="border-t border-slate-700 mt-8 pt-8 text-center text-sm text-slate-400">
          <p>&copy; 2024 Calculator.net. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

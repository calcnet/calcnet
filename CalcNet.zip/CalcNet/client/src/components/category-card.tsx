import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';

interface CategoryCardProps {
  title: string;
  imageUrl: string;
  imageAlt: string;
  items: string[];
  href: string;
}

export function CategoryCard({ title, imageUrl, imageAlt, items, href }: CategoryCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-xl transition-shadow">
      <img 
        src={imageUrl} 
        alt={imageAlt} 
        className="w-full h-48 object-cover"
      />
      <CardContent className="p-6">
        <h3 className="text-xl font-semibold text-slate-800 mb-3">{title}</h3>
        <ul className="space-y-2 text-sm text-slate-600">
          {items.map((item, index) => (
            <li key={index}>
              <Link href={href}>
                <a className="hover:text-blue-600 transition-colors">{item}</a>
              </Link>
            </li>
          ))}
        </ul>
        <Link href={href}>
          <Button variant="link" className="mt-4 p-0 h-auto text-blue-600 font-medium">
            View All →
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}

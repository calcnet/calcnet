import { useCalculator } from '@/hooks/use-calculator';
import { CalculatorDisplay } from './calculator-display';
import { CalculatorHistory } from './calculator-history';
import { Button } from '@/components/ui/button';

export function ScientificCalculator() {
  const calculator = useCalculator();

  return (
    <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-lg p-6">
      <CalculatorDisplay state={calculator.state} />
      <CalculatorHistory history={calculator.history} />

      <div className="grid grid-cols-2 gap-6">
        {/* Scientific Functions Panel */}
        <div className="space-y-2">
          <div className="flex items-center justify-between mb-3">
            <div className="flex space-x-2">
              <Button
                variant={calculator.state.angleMode === 'deg' ? 'default' : 'secondary'}
                size="sm"
                onClick={calculator.toggleAngleMode}
                className="px-3 py-1 text-sm"
              >
                Deg
              </Button>
              <Button
                variant={calculator.state.angleMode === 'rad' ? 'default' : 'secondary'}
                size="sm"
                onClick={calculator.toggleAngleMode}
                className="px-3 py-1 text-sm"
              >
                Rad
              </Button>
            </div>
          </div>

          {/* Scientific Function Buttons */}
          <div className="grid grid-cols-4 gap-2">
            {/* Row 1 */}
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.scientificFunction('sin')}
              className="calc-button-function"
            >
              sin
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.scientificFunction('cos')}
              className="calc-button-function"
            >
              cos
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.scientificFunction('tan')}
              className="calc-button-function"
            >
              tan
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.scientificFunction('log')}
              className="calc-button-function"
            >
              log
            </Button>

            {/* Row 2 */}
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.scientificFunction('asin')}
              className="calc-button-function"
            >
              sin⁻¹
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.scientificFunction('acos')}
              className="calc-button-function"
            >
              cos⁻¹
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.scientificFunction('atan')}
              className="calc-button-function"
            >
              tan⁻¹
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.scientificFunction('ln')}
              className="calc-button-function"
            >
              ln
            </Button>

            {/* Row 3 */}
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.scientificFunction('power')}
              className="calc-button-function"
            >
              x^y
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.scientificFunction('cube')}
              className="calc-button-function"
            >
              x³
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.scientificFunction('square')}
              className="calc-button-function"
            >
              x²
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.scientificFunction('exp')}
              className="calc-button-function"
            >
              eˣ
            </Button>

            {/* Row 4 */}
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.scientificFunction('sqrt')}
              className="calc-button-function"
            >
              √x
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.scientificFunction('cbrt')}
              className="calc-button-function"
            >
              ∛x
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.scientificFunction('reciprocal')}
              className="calc-button-function"
            >
              1/x
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.scientificFunction('factorial')}
              className="calc-button-function"
            >
              n!
            </Button>

            {/* Row 5 */}
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.insertConstant('pi')}
              className="calc-button-function"
            >
              π
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.insertConstant('e')}
              className="calc-button-function"
            >
              e
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.insertOperator('(')}
              className="calc-button-function"
            >
              (
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.insertOperator(')')}
              className="calc-button-function"
            >
              )
            </Button>
          </div>
        </div>

        {/* Basic Calculator Panel */}
        <div className="space-y-2">
          {/* Memory and Special Functions */}
          <div className="grid grid-cols-5 gap-2 mb-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.memoryFunction('mc')}
              className="calc-button-memory"
            >
              MC
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.memoryFunction('mr')}
              className="calc-button-memory"
            >
              MR
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.memoryFunction('mplus')}
              className="calc-button-memory"
            >
              M+
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => calculator.memoryFunction('mminus')}
              className="calc-button-memory"
            >
              M-
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={calculator.clearAll}
              className="calc-button-clear"
            >
              AC
            </Button>
          </div>

          {/* Number Pad and Operations */}
          <div className="grid grid-cols-4 gap-2">
            {/* Row 1 */}
            <Button
              variant="outline"
              onClick={calculator.backspace}
              className="calc-button-function py-4 px-4"
            >
              ⌫
            </Button>
            <Button
              variant="outline"
              onClick={() => calculator.insertOperator('%')}
              className="calc-button-function py-4 px-4"
            >
              %
            </Button>
            <Button
              variant="outline"
              onClick={() => calculator.insertOperator('exp')}
              className="calc-button-function py-4 px-4"
            >
              EXP
            </Button>
            <Button
              onClick={() => calculator.insertOperator('÷')}
              className="calc-button-operator py-4 px-4"
            >
              ÷
            </Button>

            {/* Row 2 */}
            <Button
              variant="outline"
              onClick={() => calculator.insertNumber('7')}
              className="calc-button-number py-4 px-4 text-lg"
            >
              7
            </Button>
            <Button
              variant="outline"
              onClick={() => calculator.insertNumber('8')}
              className="calc-button-number py-4 px-4 text-lg"
            >
              8
            </Button>
            <Button
              variant="outline"
              onClick={() => calculator.insertNumber('9')}
              className="calc-button-number py-4 px-4 text-lg"
            >
              9
            </Button>
            <Button
              onClick={() => calculator.insertOperator('×')}
              className="calc-button-operator py-4 px-4"
            >
              ×
            </Button>

            {/* Row 3 */}
            <Button
              variant="outline"
              onClick={() => calculator.insertNumber('4')}
              className="calc-button-number py-4 px-4 text-lg"
            >
              4
            </Button>
            <Button
              variant="outline"
              onClick={() => calculator.insertNumber('5')}
              className="calc-button-number py-4 px-4 text-lg"
            >
              5
            </Button>
            <Button
              variant="outline"
              onClick={() => calculator.insertNumber('6')}
              className="calc-button-number py-4 px-4 text-lg"
            >
              6
            </Button>
            <Button
              onClick={() => calculator.insertOperator('−')}
              className="calc-button-operator py-4 px-4"
            >
              −
            </Button>

            {/* Row 4 */}
            <Button
              variant="outline"
              onClick={() => calculator.insertNumber('1')}
              className="calc-button-number py-4 px-4 text-lg"
            >
              1
            </Button>
            <Button
              variant="outline"
              onClick={() => calculator.insertNumber('2')}
              className="calc-button-number py-4 px-4 text-lg"
            >
              2
            </Button>
            <Button
              variant="outline"
              onClick={() => calculator.insertNumber('3')}
              className="calc-button-number py-4 px-4 text-lg"
            >
              3
            </Button>
            <Button
              onClick={() => calculator.insertOperator('+')}
              className="calc-button-operator py-4 px-4"
            >
              +
            </Button>

            {/* Row 5 */}
            <Button
              variant="outline"
              onClick={calculator.toggleSign}
              className="calc-button-function py-4 px-4"
            >
              ±
            </Button>
            <Button
              variant="outline"
              onClick={() => calculator.insertNumber('0')}
              className="calc-button-number py-4 px-4 text-lg"
            >
              0
            </Button>
            <Button
              variant="outline"
              onClick={calculator.insertDecimal}
              className="calc-button-function py-4 px-4"
            >
              .
            </Button>
            <Button
              onClick={calculator.calculate}
              className="calc-button-equals py-4 px-4 text-lg"
            >
              =
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

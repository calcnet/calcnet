import { HistoryItem } from '@/hooks/use-calculator';

interface CalculatorHistoryProps {
  history: HistoryItem[];
}

export function CalculatorHistory({ history }: CalculatorHistoryProps) {
  if (history.length === 0) {
    return (
      <div className="mb-4 bg-slate-50 rounded-lg p-3 max-h-24 overflow-y-auto">
        <div className="text-sm text-slate-400 text-center">No calculations yet</div>
      </div>
    );
  }

  return (
    <div className="mb-4 bg-slate-50 rounded-lg p-3 max-h-24 overflow-y-auto">
      <div className="text-sm text-slate-600 space-y-1">
        {history.slice(0, 3).map((item, index) => (
          <div key={index} className="flex justify-between">
            <span className="truncate flex-1 mr-2">{item.expression}</span>
            <span className="font-medium">{item.result}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

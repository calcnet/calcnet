import { CalculatorState } from '@/lib/calculator';

interface CalculatorDisplayProps {
  state: CalculatorState;
}

export function CalculatorDisplay({ state }: CalculatorDisplayProps) {
  return (
    <div className="mb-6">
      <div className="bg-slate-900 text-white p-4 rounded-lg">
        {state.previousCalculation && (
          <div className="text-right text-sm text-slate-400 mb-1">
            {state.previousCalculation}
          </div>
        )}
        <div className="text-right text-3xl font-mono break-all">
          {state.display}
        </div>
      </div>
    </div>
  );
}

import { useState, useCallback, useEffect } from 'react';
import { Calculator, CalculatorState, initialState } from '@/lib/calculator';

export interface HistoryItem {
  expression: string;
  result: string;
  timestamp: Date;
}

export function useCalculator() {
  const [state, setState] = useState<CalculatorState>(initialState);
  const [history, setHistory] = useState<HistoryItem[]>([]);

  const updateDisplay = useCallback((newDisplay: string) => {
    setState(prev => ({ ...prev, display: newDisplay }));
  }, []);

  const insertNumber = useCallback((number: string) => {
    setState(prev => {
      if (prev.isNewNumber || prev.display === '0') {
        return { ...prev, display: number, isNewNumber: false };
      }
      return { ...prev, display: prev.display + number, isNewNumber: false };
    });
  }, []);

  const insertDecimal = useCallback(() => {
    setState(prev => {
      if (prev.isNewNumber) {
        return { ...prev, display: '0.', isNewNumber: false };
      }
      if (prev.display.includes('.')) {
        return prev;
      }
      return { ...prev, display: prev.display + '.', isNewNumber: false };
    });
  }, []);

  const insertOperator = useCallback((operator: string) => {
    setState(prev => {
      const currentValue = parseFloat(prev.display);
      
      if (prev.pendingOperation && !prev.isNewNumber) {
        // Calculate the result of the pending operation first
        try {
          const result = Calculator.evaluateExpression(
            `${prev.operand} ${prev.pendingOperation} ${currentValue}`
          );
          const newDisplay = Calculator.formatNumber(result);
          return {
            ...prev,
            display: newDisplay,
            operand: parseFloat(result),
            pendingOperation: operator,
            isNewNumber: true,
          };
        } catch (error) {
          return { ...prev, display: 'Error', isNewNumber: true };
        }
      }
      
      return {
        ...prev,
        operand: currentValue,
        pendingOperation: operator,
        isNewNumber: true,
      };
    });
  }, []);

  const calculate = useCallback(() => {
    setState(prev => {
      if (!prev.pendingOperation || prev.operand === null) {
        return prev;
      }

      try {
        const currentValue = parseFloat(prev.display);
        const expression = `${prev.operand} ${prev.pendingOperation} ${currentValue}`;
        const result = Calculator.evaluateExpression(expression, prev.angleMode);
        const formattedResult = Calculator.formatNumber(result);

        // Add to history
        const historyItem: HistoryItem = {
          expression,
          result: formattedResult,
          timestamp: new Date(),
        };

        setHistory(prevHistory => [historyItem, ...prevHistory.slice(0, 9)]);

        return {
          ...prev,
          display: formattedResult,
          previousCalculation: `${expression} =`,
          pendingOperation: null,
          operand: null,
          isNewNumber: true,
        };
      } catch (error) {
        return { ...prev, display: 'Error', isNewNumber: true };
      }
    });
  }, []);

  const scientificFunction = useCallback((func: string) => {
    setState(prev => {
      try {
        const currentValue = parseFloat(prev.display);
        
        if (func === 'power') {
          // Special case for power function - wait for second operand
          return {
            ...prev,
            operand: currentValue,
            pendingOperation: '^',
            isNewNumber: true,
          };
        }

        const result = Calculator.scientificFunction(func, currentValue, prev.angleMode);
        const formattedResult = Calculator.formatNumber(result.toString());
        
        // Add to history
        const expression = `${func}(${currentValue})`;
        const historyItem: HistoryItem = {
          expression,
          result: formattedResult,
          timestamp: new Date(),
        };

        setHistory(prevHistory => [historyItem, ...prevHistory.slice(0, 9)]);

        return {
          ...prev,
          display: formattedResult,
          previousCalculation: `${expression} =`,
          isNewNumber: true,
        };
      } catch (error) {
        return { ...prev, display: 'Error', isNewNumber: true };
      }
    });
  }, []);

  const insertConstant = useCallback((constant: string) => {
    const constants = Calculator.getConstants();
    const value = constants[constant];
    if (value !== undefined) {
      setState(prev => ({
        ...prev,
        display: Calculator.formatNumber(value.toString()),
        isNewNumber: true,
      }));
    }
  }, []);

  const memoryFunction = useCallback((func: string) => {
    setState(prev => {
      const currentValue = parseFloat(prev.display);
      
      switch (func) {
        case 'mc':
          return { ...prev, memory: 0 };
        case 'mr':
          return { 
            ...prev, 
            display: Calculator.formatNumber(prev.memory.toString()),
            isNewNumber: true 
          };
        case 'mplus':
          return { ...prev, memory: prev.memory + currentValue };
        case 'mminus':
          return { ...prev, memory: prev.memory - currentValue };
        default:
          return prev;
      }
    });
  }, []);

  const clearAll = useCallback(() => {
    setState(initialState);
  }, []);

  const backspace = useCallback(() => {
    setState(prev => {
      if (prev.isNewNumber || prev.display === '0' || prev.display === 'Error') {
        return { ...prev, display: '0', isNewNumber: true };
      }
      
      const newDisplay = prev.display.slice(0, -1);
      return {
        ...prev,
        display: newDisplay || '0',
        isNewNumber: newDisplay === '',
      };
    });
  }, []);

  const toggleSign = useCallback(() => {
    setState(prev => {
      if (prev.display === '0' || prev.display === 'Error') {
        return prev;
      }
      
      const newDisplay = prev.display.startsWith('-') 
        ? prev.display.slice(1) 
        : '-' + prev.display;
        
      return { ...prev, display: newDisplay };
    });
  }, []);

  const toggleAngleMode = useCallback(() => {
    setState(prev => ({
      ...prev,
      angleMode: prev.angleMode === 'deg' ? 'rad' : 'deg',
    }));
  }, []);

  // Keyboard support
  useEffect(() => {
    const handleKeydown = (e: KeyboardEvent) => {
      e.preventDefault();
      
      if (e.key >= '0' && e.key <= '9') {
        insertNumber(e.key);
      } else if (e.key === '.') {
        insertDecimal();
      } else if (e.key === '+') {
        insertOperator('+');
      } else if (e.key === '-') {
        insertOperator('-');
      } else if (e.key === '*') {
        insertOperator('×');
      } else if (e.key === '/') {
        insertOperator('÷');
      } else if (e.key === 'Enter' || e.key === '=') {
        calculate();
      } else if (e.key === 'Escape') {
        clearAll();
      } else if (e.key === 'Backspace') {
        backspace();
      }
    };

    window.addEventListener('keydown', handleKeydown);
    return () => window.removeEventListener('keydown', handleKeydown);
  }, [insertNumber, insertDecimal, insertOperator, calculate, clearAll, backspace]);

  return {
    state,
    history,
    insertNumber,
    insertDecimal,
    insertOperator,
    calculate,
    scientificFunction,
    insertConstant,
    memoryFunction,
    clearAll,
    backspace,
    toggleSign,
    toggleAngleMode,
  };
}

import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { ScientificCalculator } from '@/components/calculator/scientific-calculator';
import { CategoryCard } from '@/components/category-card';
import { Input } from '@/components/ui/input';
import { Search, Home, Weight, Percent, Car, Flame, Clock } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'wouter';

export default function HomePage() {
  const [searchQuery, setSearchQuery] = useState('');

  const categories = [
    {
      title: 'Financial Calculators',
      imageUrl: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=200',
      imageAlt: 'Financial calculator workspace',
      items: [
        'Mortgage Calculator',
        'Loan Calculator',
        'Investment Calculator',
        'Retirement Calculator',
        'Interest Calculator',
      ],
      href: '/financial',
    },
    {
      title: 'Fitness & Health Calculators',
      imageUrl: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=200',
      imageAlt: 'Fitness and health tracking equipment',
      items: [
        'BMI Calculator',
        'Calorie Calculator',
        'Body Fat Calculator',
        'BMR Calculator',
        'Ideal Weight Calculator',
      ],
      href: '/health',
    },
    {
      title: 'Math Calculators',
      imageUrl: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=200',
      imageAlt: 'Mathematical formulas on blackboard',
      items: [
        'Scientific Calculator',
        'Fraction Calculator',
        'Percentage Calculator',
        'Triangle Calculator',
        'Standard Deviation Calculator',
      ],
      href: '/math',
    },
    {
      title: 'Other Calculators',
      imageUrl: 'https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=200',
      imageAlt: 'Various tools and utilities',
      items: [
        'Age Calculator',
        'Date Calculator',
        'Time Calculator',
        'GPA Calculator',
        'Password Generator',
      ],
      href: '/other',
    },
  ];

  const popularCalculators = [
    { icon: Home, name: 'Mortgage', href: '/financial' },
    { icon: Weight, name: 'BMI', href: '/health' },
    { icon: Percent, name: 'Percentage', href: '/math' },
    { icon: Car, name: 'Auto Loan', href: '/financial' },
    { icon: Flame, name: 'Calorie', href: '/health' },
    { icon: Clock, name: 'Time', href: '/other' },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Section */}
        <div className="mb-8">
          <div className="max-w-2xl mx-auto">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search for a calculator..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full px-4 py-3 pl-12 text-lg border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
              />
              <Search className="absolute left-4 top-4 text-slate-400 h-5 w-5" />
            </div>
          </div>
        </div>

        {/* Scientific Calculator Section */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-slate-800 mb-6 text-center">
            Scientific Calculator
          </h2>
          <ScientificCalculator />
        </div>

        {/* Calculator Categories Section */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-slate-800 mb-8 text-center">
            Free Online Calculators
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((category) => (
              <CategoryCard
                key={category.title}
                title={category.title}
                imageUrl={category.imageUrl}
                imageAlt={category.imageAlt}
                items={category.items}
                href={category.href}
              />
            ))}
          </div>
        </div>

        {/* Popular Calculators Section */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          <h2 className="text-2xl font-bold text-slate-800 mb-6">
            Most Popular Calculators
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {popularCalculators.map((calc) => {
              const IconComponent = calc.icon;
              return (
                <Link key={calc.name} href={calc.href}>
                  <a className="text-center p-4 rounded-lg hover:bg-slate-50 transition-colors group">
                    <IconComponent className="h-8 w-8 text-blue-600 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                    <div className="text-sm font-medium text-slate-700">
                      {calc.name}
                    </div>
                  </a>
                </Link>
              );
            })}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}

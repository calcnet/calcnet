import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useState } from 'react';

export default function FinancialPage() {
  const [mortgageData, setMortgageData] = useState({
    loanAmount: '',
    interestRate: '',
    loanTerm: '',
    downPayment: '',
  });

  const [mortgageResult, setMortgageResult] = useState<{
    monthlyPayment: number;
    totalPayment: number;
    totalInterest: number;
  } | null>(null);

  const calculateMortgage = () => {
    const principal = parseFloat(mortgageData.loanAmount) - parseFloat(mortgageData.downPayment || '0');
    const monthlyRate = parseFloat(mortgageData.interestRate) / 100 / 12;
    const numPayments = parseFloat(mortgageData.loanTerm) * 12;

    if (principal <= 0 || monthlyRate <= 0 || numPayments <= 0) {
      return;
    }

    const monthlyPayment = principal * (monthlyRate * Math.pow(1 + monthlyRate, numPayments)) / 
                          (Math.pow(1 + monthlyRate, numPayments) - 1);
    
    const totalPayment = monthlyPayment * numPayments;
    const totalInterest = totalPayment - principal;

    setMortgageResult({
      monthlyPayment,
      totalPayment,
      totalInterest,
    });
  };

  const calculators = [
    {
      title: 'Mortgage Calculator',
      description: 'Calculate your monthly mortgage payments',
      isActive: true,
    },
    {
      title: 'Loan Calculator',
      description: 'Calculate personal loan payments',
      isActive: false,
    },
    {
      title: 'Auto Loan Calculator',
      description: 'Calculate car loan payments',
      isActive: false,
    },
    {
      title: 'Investment Calculator',
      description: 'Calculate investment returns',
      isActive: false,
    },
    {
      title: 'Retirement Calculator',
      description: 'Plan your retirement savings',
      isActive: false,
    },
    {
      title: 'Interest Calculator',
      description: 'Calculate compound interest',
      isActive: false,
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-4xl font-bold text-slate-800 mb-8 text-center">
          Financial Calculators
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Calculator List */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Available Calculators</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {calculators.map((calc) => (
                  <Button
                    key={calc.title}
                    variant={calc.isActive ? 'default' : 'ghost'}
                    className="w-full justify-start text-left"
                    disabled={!calc.isActive}
                  >
                    <div>
                      <div className="font-medium">{calc.title}</div>
                      <div className="text-sm text-muted-foreground">
                        {calc.description}
                      </div>
                    </div>
                  </Button>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Active Calculator */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Mortgage Calculator</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="loanAmount">Loan Amount ($)</Label>
                    <Input
                      id="loanAmount"
                      type="number"
                      placeholder="300,000"
                      value={mortgageData.loanAmount}
                      onChange={(e) => setMortgageData({ ...mortgageData, loanAmount: e.target.value })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="downPayment">Down Payment ($)</Label>
                    <Input
                      id="downPayment"
                      type="number"
                      placeholder="60,000"
                      value={mortgageData.downPayment}
                      onChange={(e) => setMortgageData({ ...mortgageData, downPayment: e.target.value })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="interestRate">Interest Rate (%)</Label>
                    <Input
                      id="interestRate"
                      type="number"
                      step="0.01"
                      placeholder="4.5"
                      value={mortgageData.interestRate}
                      onChange={(e) => setMortgageData({ ...mortgageData, interestRate: e.target.value })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="loanTerm">Loan Term (years)</Label>
                    <Select 
                      value={mortgageData.loanTerm}
                      onValueChange={(value) => setMortgageData({ ...mortgageData, loanTerm: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select term" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="15">15 years</SelectItem>
                        <SelectItem value="20">20 years</SelectItem>
                        <SelectItem value="25">25 years</SelectItem>
                        <SelectItem value="30">30 years</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Button onClick={calculateMortgage} className="w-full">
                  Calculate Monthly Payment
                </Button>

                {mortgageResult && (
                  <div className="bg-slate-50 rounded-lg p-6 space-y-4">
                    <h3 className="text-lg font-semibold">Calculation Results</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">
                          ${mortgageResult.monthlyPayment.toLocaleString('en-US', { 
                            minimumFractionDigits: 2, 
                            maximumFractionDigits: 2 
                          })}
                        </div>
                        <div className="text-sm text-slate-600">Monthly Payment</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-slate-800">
                          ${mortgageResult.totalPayment.toLocaleString('en-US', { 
                            minimumFractionDigits: 2, 
                            maximumFractionDigits: 2 
                          })}
                        </div>
                        <div className="text-sm text-slate-600">Total Payment</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-slate-800">
                          ${mortgageResult.totalInterest.toLocaleString('en-US', { 
                            minimumFractionDigits: 2, 
                            maximumFractionDigits: 2 
                          })}
                        </div>
                        <div className="text-sm text-slate-600">Total Interest</div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}

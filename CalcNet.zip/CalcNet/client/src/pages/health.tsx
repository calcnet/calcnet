import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useState } from 'react';

export default function HealthPage() {
  const [bmiData, setBmiData] = useState({
    height: '',
    weight: '',
    unit: 'metric',
  });

  const [bmiResult, setBmiResult] = useState<{
    bmi: number;
    category: string;
    color: string;
  } | null>(null);

  const calculateBMI = () => {
    const weight = parseFloat(bmiData.weight);
    let height = parseFloat(bmiData.height);

    if (!weight || !height) return;

    // Convert to metric if needed
    if (bmiData.unit === 'imperial') {
      // Convert pounds to kg and inches to meters
      const weightKg = weight * 0.453592;
      const heightM = height * 0.0254;
      height = heightM;
      const bmi = weightKg / (heightM * heightM);
      setBMIResult(bmi);
    } else {
      // Height in cm, convert to meters
      const heightM = height / 100;
      const bmi = weight / (heightM * heightM);
      setBMIResult(bmi);
    }
  };

  const setBMIResult = (bmi: number) => {
    let category = '';
    let color = '';

    if (bmi < 18.5) {
      category = 'Underweight';
      color = 'text-blue-600';
    } else if (bmi < 25) {
      category = 'Normal weight';
      color = 'text-green-600';
    } else if (bmi < 30) {
      category = 'Overweight';
      color = 'text-yellow-600';
    } else {
      category = 'Obese';
      color = 'text-red-600';
    }

    setBmiResult({ bmi, category, color });
  };

  const calculators = [
    {
      title: 'BMI Calculator',
      description: 'Calculate your Body Mass Index',
      isActive: true,
    },
    {
      title: 'Calorie Calculator',
      description: 'Calculate daily calorie needs',
      isActive: false,
    },
    {
      title: 'Body Fat Calculator',
      description: 'Estimate body fat percentage',
      isActive: false,
    },
    {
      title: 'BMR Calculator',
      description: 'Calculate Basal Metabolic Rate',
      isActive: false,
    },
    {
      title: 'Ideal Weight Calculator',
      description: 'Find your ideal weight range',
      isActive: false,
    },
    {
      title: 'Pace Calculator',
      description: 'Calculate running pace',
      isActive: false,
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-4xl font-bold text-slate-800 mb-8 text-center">
          Health & Fitness Calculators
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Calculator List */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Available Calculators</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {calculators.map((calc) => (
                  <Button
                    key={calc.title}
                    variant={calc.isActive ? 'default' : 'ghost'}
                    className="w-full justify-start text-left"
                    disabled={!calc.isActive}
                  >
                    <div>
                      <div className="font-medium">{calc.title}</div>
                      <div className="text-sm text-muted-foreground">
                        {calc.description}
                      </div>
                    </div>
                  </Button>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Active Calculator */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>BMI Calculator</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="unit">Unit System</Label>
                    <Select 
                      value={bmiData.unit}
                      onValueChange={(value) => setBmiData({ ...bmiData, unit: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="metric">Metric (kg, cm)</SelectItem>
                        <SelectItem value="imperial">Imperial (lbs, inches)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="weight">
                        Weight ({bmiData.unit === 'metric' ? 'kg' : 'lbs'})
                      </Label>
                      <Input
                        id="weight"
                        type="number"
                        step="0.1"
                        placeholder={bmiData.unit === 'metric' ? '70' : '154'}
                        value={bmiData.weight}
                        onChange={(e) => setBmiData({ ...bmiData, weight: e.target.value })}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="height">
                        Height ({bmiData.unit === 'metric' ? 'cm' : 'inches'})
                      </Label>
                      <Input
                        id="height"
                        type="number"
                        step="0.1"
                        placeholder={bmiData.unit === 'metric' ? '175' : '69'}
                        value={bmiData.height}
                        onChange={(e) => setBmiData({ ...bmiData, height: e.target.value })}
                      />
                    </div>
                  </div>
                </div>

                <Button onClick={calculateBMI} className="w-full">
                  Calculate BMI
                </Button>

                {bmiResult && (
                  <div className="bg-slate-50 rounded-lg p-6 space-y-4">
                    <h3 className="text-lg font-semibold">BMI Result</h3>
                    <div className="text-center">
                      <div className="text-4xl font-bold text-blue-600 mb-2">
                        {bmiResult.bmi.toFixed(1)}
                      </div>
                      <div className={`text-lg font-semibold ${bmiResult.color}`}>
                        {bmiResult.category}
                      </div>
                    </div>
                    
                    <div className="space-y-2 text-sm text-slate-600">
                      <h4 className="font-medium text-slate-800">BMI Categories:</h4>
                      <div className="grid grid-cols-2 gap-2">
                        <div>Underweight: Below 18.5</div>
                        <div>Normal: 18.5 - 24.9</div>
                        <div>Overweight: 25.0 - 29.9</div>
                        <div>Obese: 30.0 and above</div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}

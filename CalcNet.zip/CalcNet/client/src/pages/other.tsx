import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useState } from 'react';

export default function OtherPage() {
  const [ageData, setAgeData] = useState({
    birthDate: '',
  });

  const [ageResult, setAgeResult] = useState<{
    years: number;
    months: number;
    days: number;
    totalDays: number;
  } | null>(null);

  const calculateAge = () => {
    if (!ageData.birthDate) return;

    const birthDate = new Date(ageData.birthDate);
    const today = new Date();
    
    let years = today.getFullYear() - birthDate.getFullYear();
    let months = today.getMonth() - birthDate.getMonth();
    let days = today.getDate() - birthDate.getDate();

    if (days < 0) {
      months--;
      const daysInLastMonth = new Date(today.getFullYear(), today.getMonth(), 0).getDate();
      days += daysInLastMonth;
    }

    if (months < 0) {
      years--;
      months += 12;
    }

    const totalDays = Math.floor((today.getTime() - birthDate.getTime()) / (1000 * 60 * 60 * 24));

    setAgeResult({ years, months, days, totalDays });
  };

  const calculators = [
    {
      title: 'Age Calculator',
      description: 'Calculate your exact age',
      isActive: true,
    },
    {
      title: 'Date Calculator',
      description: 'Calculate date differences',
      isActive: false,
    },
    {
      title: 'Time Calculator',
      description: 'Add and subtract time',
      isActive: false,
    },
    {
      title: 'Hours Calculator',
      description: 'Calculate work hours',
      isActive: false,
    },
    {
      title: 'GPA Calculator',
      description: 'Calculate grade point average',
      isActive: false,
    },
    {
      title: 'Grade Calculator',
      description: 'Calculate grades and scores',
      isActive: false,
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-4xl font-bold text-slate-800 mb-8 text-center">
          Other Calculators
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Calculator List */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Available Calculators</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {calculators.map((calc) => (
                  <Button
                    key={calc.title}
                    variant={calc.isActive ? 'default' : 'ghost'}
                    className="w-full justify-start text-left"
                    disabled={!calc.isActive}
                  >
                    <div>
                      <div className="font-medium">{calc.title}</div>
                      <div className="text-sm text-muted-foreground">
                        {calc.description}
                      </div>
                    </div>
                  </Button>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Active Calculator */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Age Calculator</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="birthDate">Birth Date</Label>
                    <Input
                      id="birthDate"
                      type="date"
                      value={ageData.birthDate}
                      onChange={(e) => setAgeData({ ...ageData, birthDate: e.target.value })}
                    />
                  </div>
                </div>

                <Button onClick={calculateAge} className="w-full">
                  Calculate Age
                </Button>

                {ageResult && (
                  <div className="bg-slate-50 rounded-lg p-6 space-y-4">
                    <h3 className="text-lg font-semibold">Age Result</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-blue-600">
                          {ageResult.years}
                        </div>
                        <div className="text-sm text-slate-600">Years</div>
                      </div>
                      <div className="text-center">
                        <div className="text-3xl font-bold text-blue-600">
                          {ageResult.months}
                        </div>
                        <div className="text-sm text-slate-600">Months</div>
                      </div>
                      <div className="text-center">
                        <div className="text-3xl font-bold text-blue-600">
                          {ageResult.days}
                        </div>
                        <div className="text-sm text-slate-600">Days</div>
                      </div>
                      <div className="text-center">
                        <div className="text-3xl font-bold text-slate-800">
                          {ageResult.totalDays.toLocaleString()}
                        </div>
                        <div className="text-sm text-slate-600">Total Days</div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}

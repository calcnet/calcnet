import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { ScientificCalculator } from '@/components/calculator/scientific-calculator';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export default function MathPage() {
  const calculators = [
    {
      title: 'Scientific Calculator',
      description: 'Advanced mathematical calculations',
      isActive: true,
    },
    {
      title: 'Fraction Calculator',
      description: 'Add, subtract, multiply fractions',
      isActive: false,
    },
    {
      title: 'Percentage Calculator',
      description: 'Calculate percentages',
      isActive: false,
    },
    {
      title: 'Triangle Calculator',
      description: 'Calculate triangle properties',
      isActive: false,
    },
    {
      title: 'Standard Deviation Calculator',
      description: 'Statistical calculations',
      isActive: false,
    },
    {
      title: 'Random Number Generator',
      description: 'Generate random numbers',
      isActive: false,
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-4xl font-bold text-slate-800 mb-8 text-center">
          Math Calculators
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Calculator List */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Available Calculators</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {calculators.map((calc) => (
                  <Button
                    key={calc.title}
                    variant={calc.isActive ? 'default' : 'ghost'}
                    className="w-full justify-start text-left"
                    disabled={!calc.isActive}
                  >
                    <div>
                      <div className="font-medium">{calc.title}</div>
                      <div className="text-sm text-muted-foreground">
                        {calc.description}
                      </div>
                    </div>
                  </Button>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Active Calculator */}
          <div className="lg:col-span-3">
            <h2 className="text-2xl font-bold text-slate-800 mb-6">
              Scientific Calculator
            </h2>
            <ScientificCalculator />
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}

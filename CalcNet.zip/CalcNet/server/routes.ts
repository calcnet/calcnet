import type { Express } from "express";
import { createServer, type Server } from "http";

export async function registerRoutes(app: Express): Promise<Server> {
  // For this calculator application, most functionality is client-side
  // The backend can be used for storing calculation history if needed
  
  // Basic API health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", message: "Calculator API is running" });
  });

  // Future endpoints for calculator history, user preferences, etc.
  // app.get("/api/calculator/history", ...)
  // app.post("/api/calculator/history", ...)

  const httpServer = createServer(app);
  return httpServer;
}

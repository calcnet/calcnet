import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const calculatorHistory = pgTable("calculator_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  expression: text("expression").notNull(),
  result: text("result").notNull(),
  calculatorType: varchar("calculator_type").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertCalculatorHistorySchema = createInsertSchema(calculatorHistory).omit({
  id: true,
  timestamp: true,
});

export type InsertCalculatorHistory = z.infer<typeof insertCalculatorHistorySchema>;
export type CalculatorHistory = typeof calculatorHistory.$inferSelect;
